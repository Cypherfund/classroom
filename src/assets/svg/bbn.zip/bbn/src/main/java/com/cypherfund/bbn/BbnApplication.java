package com.cypherfund.bbn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbnApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbnApplication.class, args);
	}

}
