package com.cypherfund.bbn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BbnApplicationTests {

	@Test
	void contextLoads() {
	}

}
